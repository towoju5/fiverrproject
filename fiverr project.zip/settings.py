import os

header = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'}

DATA_DIR = 'data'
OUTPUT_DIR = 'outputs'
INPUT_DIR = 'inputs'
postal_file = os.path.join(INPUT_DIR, 'postalcodes.csv')
template_file = os.path.join(DATA_DIR, 'template.xlsx')
# output_file = os.path.join(OUTPUT_DIR, 'output.xlsx')
main_url = 'https://www.streetcheck.co.uk'
district_url = 'https://www.streetcheck.co.uk/postcode/startingwith/{postal_code}'
