import os, sys
import shutil
import csv
import string
import time
import datetime
# external modules 
import fake_useragent
import openpyxl

# user modules 
from StreetCheck import StreetCheck
from functions import *
import settings


if __name__ == '__main__':
	print('-'*50)
	print('-- StreetCheck Scraper BOT -- ')
	print('-'*50)

	# read in csv files for postal code 
	POSTAL_CODES = read_postal_codes()
	print(f'Loaded {len(POSTAL_CODES)} from input file .. ')
	# initialize street check handle
	streetcheck_handler = StreetCheck()

	# copy the template from data over to the output folder
	# create output folder if it does not extsts. 
	# output_file = os.path.join(settings.OUTPUT_DIR, settings.output_file)

	print('Duplicating Template Output .. ', end='', flush=True)
	os.makedirs(settings.OUTPUT_DIR, exist_ok=True)

	# get the current date to be use in renaming the file 
	curr_date = datetime.datetime.now().strftime('%d%m%Y')
	
	output_file = os.path.join(settings.OUTPUT_DIR, f'POSTCODE_AREAINFO_{curr_date}.xlsx')
	shutil.copy(settings.template_file, output_file)
	print('Template Duplicated !')


	# acquire handle to workbook 
	workbook = openpyxl.load_workbook(output_file)
	source = workbook.get_sheet_by_name('Template')

	postal_count = 0
	print()
	# process the postal codes 
	for postal_code in POSTAL_CODES:
		# we are using the first sheet as boiler plate for the others
		current_sheet = workbook.copy_worksheet(source)
		# rename the duplicated tab to the current district  post code 
		current_sheet.title = postal_code

		# visit the district URL for the postal code 
		current_URL = settings.district_url.format(postal_code=postal_code)
		print(f'Extracting Area information from {current_URL}')
		area_links = streetcheck_handler.fetch_area_info(current_URL)
		print(f'There are #{len(area_links)} dictrict under postal code: {postal_code} to be scraped!\n')
		time.sleep(3)
		district_count = 0
		row_index = 4 # increment for each loop
		for i,area_link in enumerate(area_links):
			current_postal_code = area_link.split('/')[-1]
			full_area_link = ''.join([settings.main_url, area_link]) # create a complete URL
			print(f' - Fetching detail information from {full_area_link}')

			# fetch the soup object from the web page source
			detail_soup, road_name = streetcheck_handler.detail_connect(full_area_link)
			if detail_soup:
				pirnt_flush(f' \t-- Writing Details of district {current_postal_code} to output file ... ')
				
				# fetch the summary pane details
				detail_summary = streetcheck_handler.detail_extract_summary(detail_soup)
				detail_summary = [format_postcode(current_postal_code), road_name] + list(detail_summary)
				# print(detail_summary)
				for idx, cell in enumerate(row_gen(f'A{row_index}', k=5)): # A4 to D4
				 	# print(f'{detail_summary[idx]} == > {cell}')
				 	current_sheet[cell] = detail_summary[idx]

				# write the housing types .. 
				housing_types = streetcheck_handler.detail_extract_housing_types(detail_soup)
				for idx, cell in enumerate(row_gen(f'F{row_index}', k=6)): # A4 to D4
				 	current_sheet[cell] = housing_types[idx]

				# write the housing tenures .. 
				housing_tenure = streetcheck_handler.detail_extract_housing_tenure(detail_soup)
				for idx, cell in enumerate(row_gen(f'L{row_index}', k=7)): # A4 to D4
				 	current_sheet[cell] = housing_tenure[idx]

				# write the housing occupancy  .. 
				housing_occupancy = streetcheck_handler.detail_extract_housing_occupancy(detail_soup)
				for idx, cell in enumerate(row_gen(f'S{row_index}', k=8)): 
				 	current_sheet[cell] = housing_occupancy[idx]
				
				# write the housing age groups .. 
				age_groups = streetcheck_handler.detail_extract_people_age_group(detail_soup)
				for idx, cell in enumerate(row_gen(f'AA{row_index}', k=16)): 
				 	current_sheet[cell] = list(age_groups.values())[idx]
				
				# write the housing relationships  .. 
				relationship_status = streetcheck_handler.detail_extract_people_relationship_status(detail_soup)
				for idx, cell in enumerate(row_gen(f'AQ{row_index}', k=6)): 
				 	current_sheet[cell] = list(relationship_status.values())[idx]
				
				# write the housing employments .. 
				employment_activity = streetcheck_handler.detail_extract_employment_activity(detail_soup)
				for idx, cell in enumerate(row_gen(f'AW{row_index}', k=9)): 
				 	current_sheet[cell] = list(employment_activity.values())[idx]
				
				# increment the row index
				row_index += 1
				
				print('Done!')
				time.sleep(.5)

				district_count += 1
			else:
				print('... !')


		
		print(f'\nTotal of #{district_count} detail district was scraped for postal: {postal_code} \n')
		print('-'*50)
		print()
		postal_count += 1
		# workbook.save(settings.output_file)
		workbook.save(output_file)
		
	# remove the template sheet 
	try:
		workbook.remove(workbook['Template'])
	except Exception:
		pass

	workbook.save(output_file)
	# workbook.save(settings.output_file)
	print(f'\nTotal of #{postal_count} Post codes were processed \n')
	print(f'Saved in {output_file} .!')
	input('DONE, press <enter> to exit !')