import requests
import bs4
import time
import settings 

class StreetCheck(object):
	def __init__(self):
		pass

	@classmethod 
	def fetch_area_info(cls, area_url):
		area_links = []
		cnt = 0
		while True:
			try:
				r = requests.get(area_url, timeout=60, headers=settings.header)
				if r.status_code == requests.codes.ok:
					soup = bs4.BeautifulSoup(r.text, 'html.parser')
					# extract all area links
					if soup:
						all_possible_p = soup.select('div.row p')
						if all_possible_p:
							for p in all_possible_p:
								p_anchor = p.find('a')
								if p_anchor:
									if 'postcode/' in p_anchor.get('href').lower():
										if 'No Longer In Use' not in p.text:
											area_links.append(p_anchor.get('href'))
										else:
											cnt += 1

												# print(cnt, p.text, 'no longer in use')
				return area_links
			except Exception as ex:
				print('Error Occured .. !! Trying again !!')
				time.sleep(2)
				continue


	@classmethod
	def detail_connect(cls, detail_url):
		cnt = 0
		while True:
			try:
				r = requests.get(detail_url, timeout=60, headers=settings.header)
				if r.status_code == requests.codes.ok:
					soup = bs4.BeautifulSoup(r.text, 'html.parser')
					# extract all area links
					if soup:
						# ; = soup.select('div#summary .col-sm-10')[0].text.split(' ')
						# l[l.index('Road')-1] + ' Area'
						t = soup.find('h1').text.lower()
						road_name = t[t.find('for '):t.find(',')].replace('for ', '').title()
						table = soup.select('.info-piece table')
						if table:
							return table, road_name
			except (Exception, ConnectionResetError, requests.ConnectionError) as ex:
				print('Connection Error occur during detail extract .. Trying again.!')
				print(f'Reason: {ex}')
				cnt += 1
				if cnt == 3:
					print('Error Persist .. Moving on connection. ')
					return None
				time.sleep(2)
				continue

	@classmethod
	def detail_extract_summary(cls, table_soup):
		"""
			Returns local_authority, ward, constituency
			All scraped from the detail page
			fed in with the soup args parameter. 
		"""
		local_authority = ward = constituency = 'N/A'
		tbl = table_soup[0]
		if tbl:
			for tr in tbl.find_all('tr'):
				tds = tr.find_all('td')

				if 'Local Authority' in tds[0]:
					local_authority = tds[1].text.strip()

				if 'Ward' in tds[0]:
					ward = tds[1].text.strip()

				if 'Constituency' in tds[0]:
					constituency = tds[1].text.strip()

		return local_authority, ward, constituency 

	@classmethod
	def detail_extract_housing_types(cls, table_soup):
		"""
			Returns detached, semi_detached, terraced, flat_purpose,
			flat_converted, residence_commercial
		"""
		detached = semi_detached = terraced = flat_purpose = flat_converted = residence_commercial = 'N/A'

		tbl = table_soup[2] # the third table
		if tbl:
			for tr in tbl.find_all('tr')[1:]:
				tds = tr.find_all('td')
				if 'Detached' in tds[0]:
					detached = int(tds[1].text.strip())

				if 'Semi-Detached' in tds[0]:
					semi_detached = int(tds[1].text.strip())

				if 'Terraced' in tds[0]:
					terraced = int(tds[1].text.strip())

				if 'Flat (Purpose-Built)' in tds[0]:
					flat_purpose = int(tds[1].text.strip())

				if 'Flat (Converted)' in tds[0]:
					flat_converted = int(tds[1].text.strip())

				if 'Residence in Commercial Building' in tds[0]:
					residence_commercial = int(tds[1].text.strip())

		return detached, semi_detached, terraced, flat_purpose,\
			flat_converted, residence_commercial

	
	@classmethod
	def detail_extract_housing_tenure(cls, table_soup):
		"""
			Returns owned_outright, owned_mortgage, owned_shared, rented_council,
			rented_social, rented_private, rented_free
		"""
		owned_outright = owned_mortgage = owned_shared = rented_council = rented_social = rented_private = rented_free = rented_other= 'N/A'
		tbl = table_soup[3] # the 4th table
		if tbl:
			for tr in tbl.find_all('tr')[1:]: # the one off slicing is to skip the header which only contains <th>
				tds = tr.find_all('td')
				if 'Owned Outright' in tds[0]:
					owned_outright = int(tds[1].text.strip())

				if 'Owned with Mortgage' in tds[0]:
					owned_mortgage = int(tds[1].text.strip())

				if 'Shared Ownership' in tds[0]:
					owned_shared = int(tds[1].text.strip())

				if 'Rented: From Council' in tds[0]:
					rented_council = int(tds[1].text.strip())

				if 'Rented: Other Social' in tds[0]:
					rented_social = int(tds[1].text.strip())
					
				if 'Rented: Private Landlord' in tds[0]:
					rented_private = int(tds[1].text.strip())
				
				if 'Rent Free' in tds[0]:
					rented_free = int(tds[1].text.strip())
				
				if 'Rented: Other' in tds[0]:
					rented_other = int(tds[1].text.strip())
				
		return owned_outright, owned_mortgage, owned_shared, rented_council,\
			rented_social, rented_private, rented_free#, rented_other

	@classmethod
	def detail_extract_housing_occupancy(cls, table_soup):
		"""
			Returns p1, p2, p3, p4, p5, p6, p7, p8plus
		"""
		p1 = p2 = p3 = p4 = p5 = p6 = p7 = p8plus = 'N/A'
		tbl = table_soup[4] # the 8th table
		if tbl:
			for tr in tbl.find_all('tr')[1:]:
				tds = tr.find_all('td')
				if 'One Person' in tds[0]:
					p1 = int(tds[1].text.strip())

				if 'Two People' in tds[0]:
					p2 = int(tds[1].text.strip())

				if 'Three People' in tds[0]:
					p3 = int(tds[1].text.strip())

				if 'Four People' in tds[0]:
					p4 = int(tds[1].text.strip())

				if 'Five People' in tds[0]:
					p5 = int(tds[1].text.strip())
					
				if 'Six People' in tds[0]:
					p6 = int(tds[1].text.strip())
				
				if 'Seven People' in tds[0]:
					p7 = int(tds[1].text.strip())
				
				if '8+ People' in tds[0]:
					p8plus = int(tds[1].text.strip())
				
		return p1, p2, p3, p4, p5, p6, p7, p8plus

	@classmethod
	def detail_extract_people_age_group(cls, table_soup):
		tbl = table_soup[7] # the 8th table
		mapped = ['0-4', '5-7', '8-9', '10-14', '15', '16-17', '18-19', '20-24', '25-29', '30-44', '45-59', '60-64', '65-74', '75-84', '85-89', '90+']
		age_groups = [0 for _ in range(len(mapped))]
		if tbl:
			age_groups = [int(tr.find_all('td')[1].text.strip()) for tr in tbl.find_all('tr')[1:-1]]
			return dict(zip(mapped, age_groups))


	@classmethod
	def detail_extract_people_relationship_status(cls, table_soup):
		tbl = table_soup[8] # the 9th table
		# the mapped name 
		mapped = ['Single', 'Married', 'Divorced', 'Separated', 'Widowed', 'Same Sex']
		relationship_status = [0 for _ in range(len(mapped))]
		if tbl:
			relationship_status = [int(tr.find_all('td')[1].text.strip()) for tr in tbl.find_all('tr')[1:-1]]
			return dict(zip(mapped, relationship_status))


	@classmethod
	def detail_extract_employment_activity(cls, table_soup):
		tbl = table_soup[15] # the 9th table
		# the mapped name
		mapped = [
			'Full-Time Employee', 
			'Part-Time Employee', 
			'Self Employed', 
			'Unemployed', 
			'Full-Time Student', 
			'Retired', 
			'Looking After Home or Family', 
			'Long-Term Sick or Disabled', 
			'Other'
		]
		activities = [0 for _ in range(len(mapped))]
		if tbl:
			activities = [int(tr.find_all('td')[1].text.strip()) for tr in tbl.find_all('tr')[1:-1]]
			return dict(zip(mapped, activities))