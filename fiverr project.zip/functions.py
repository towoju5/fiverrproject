import string
import settings

def row_gen(cellid, k):
	if cellid[0] in string.ascii_uppercase:
		letter = cellid[0]
		figure = cellid[1:]
		if cellid[1] in string.ascii_uppercase:
			letter = cellid[0] + cellid[1]
			figure = cellid[2:]
	move_on = False
	cnt = 0
	for i in (' ' + string.ascii_uppercase):
		for j in string.ascii_uppercase:
			i = i.replace(" ", "")
			if f'{i}{j}' == letter:
				move_on = True
			if move_on:
				cnt += 1
				if cnt > k:
					raise StopIteration('Specified K has been reached')
				yield f'{i}{j}{figure}'

def read_postal_codes():
	# the additional slicing is for slicing out the header . 
	return [line.strip() for line in open(settings.postal_file, 'r')][1:]

def format_postcode(postcode):
	return ' '.join([postcode[:3], postcode[3:]]).upper()

def pirnt_flush(text):
	print(text, end='', flush=True)

